module.exports = function splitArgs(string) {
//    let segments =    
    return string.split(" ")//segments.splice(1, segments.length- 1)
}