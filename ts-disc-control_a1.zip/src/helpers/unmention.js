module.exports = function unmention(mention) {
    return mention.slice(3, -1)
}