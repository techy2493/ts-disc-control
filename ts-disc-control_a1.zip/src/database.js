const Keyv = require('keyv');
const config = require('./config');

class Database {
    
    constructor() {
        this.db = new Keyv('sqlite://' + config.database.sqlite.filename);
        this.db.on('error', err => console.error('Keyv connection error:', err));
    }

    async updateTeamspeakID(discordID, tsID){
        return await this.db.set(discordID, tsID)
    }

    async getSynchronizedRoles() {
        return await this.db.get('sync');
    }

    async setSynchronizedRoles(synced) {
        return await this.db.set('sync', synced);
    }


    async getTeamspeakIDByDiscordId(id) {
        return await this.db.get(id);
    }

}

module.exports = new Database()