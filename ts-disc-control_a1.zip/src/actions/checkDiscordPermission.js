module.exports = async function checkDiscordPermission(user, permission) {
    console.warn("Permissions not implemented")
    return true; 
}