const teamspeak = require("../teamspeak");
const btoa = require('btoa');

module.exports = async function(event) {
    return new Promise(async (resolve, reject) => {
        console.log(event.client.propcache.clientNickname)
        await teamspeak.sendMessageToClient(event.client, 'Hello! You seem to be new here. Please connect your discord account by logging in with the link below.')
        await teamspeak.sendMessageToClient(event.client, `http://localhost:8090/login?tsid=${btoa(event.client.propcache.clientUniqueIdentifier)}`)
        resolve();
    })
}