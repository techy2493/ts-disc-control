const web = require('./src/express')
const ts = require("./src/teamspeak");
const db = require("./src/database");
const discord = require("./src/discord");
const _ = require('lodash');
const teamspeakClientConnected = require('./src/actions/teamspeakClientConnected');
const synchroniseUser = require('./src/actions/synchronizeUser');
const processDiscordMessage = require('./src/actions/processDiscordMessage')


// Initialize Connections to Servers
async function initialize() {
    await ts.connect();
    await discord.connect();
        
    ts.client.on("clientconnect", async (e) => {
        await teamspeakClientConnected(e)
    })

    prepareDiscordListeners();
}

function prepareDiscordListeners() {
    discord.client.on('message', message => {
        processDiscordMessage(message);
    });
    
    discord.client.on('guildMemberUpdate', member => {
        synchroniseUser(member.guild.members.cache.get(member.id))
    })
}

initialize();